
    <!-- This page JS -->
	<!-- <script src="<?php echo base_url(); ?>skin/assets/js/js-index.js"></script>	 -->
		
	<!-- Sparkline -->	
	<script src="<?php echo base_url(); ?>skin/assets/js/jquery.sparkline.js"></script>
	
    <!-- Custom functions -->
    <script src="<?php echo base_url(); ?>skin/assets/js/functions.js"></script>
	
    <!-- Counter -->	
    <script src="<?php echo base_url(); ?>skin/assets/js/counter.js"></script>		
	
    <!-- Picker UI-->	
	<script src="<?php echo base_url(); ?>skin/assets/js/jquery-ui.js"></script>		
	
	<!-- Easing -->
    <script src="<?php echo base_url(); ?>skin/assets/js/jquery.easing.js"></script>
	
    <!-- Nicescroll  -->	
	<!-- <script src="<?php echo base_url(); ?>skin/assets/js/jquery.nicescroll.min.js"></script> -->
	
    <!-- CarouFredSel -->
    <script src="<?php echo base_url(); ?>skin/assets/js/jquery.carouFredSel-6.2.1-packed.js"></script>
    <script src="<?php echo base_url(); ?>skin/assets/js/helper-plugins/jquery.touchSwipe.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>skin/assets/js/helper-plugins/jquery.mousewheel.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>skin/assets/js/helper-plugins/jquery.transit.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>skin/assets/js/helper-plugins/jquery.ba-throttle-debounce.min.js"></script>
	
    <!-- Custom Select -->
	<script type='text/javascript' src='<?php echo base_url(); ?>skin/assets/js/jquery.customSelect.js'></script>	
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url(); ?>skin/dist/js/bootstrap.min.js"></script>

	<!-- Chart JS -->
     <!-- Chartist Charts -->
    <link rel="stylesheet" href="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.css">
    <script src="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/chartist-plugin-legend/0.6.1/chartist-plugin-legend.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <!-- MORRIS CHARTS -->
<!--     <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script> -->

    <!-- <script src="<?php echo base_url(); ?>skin/assets/js/js-dashboard.js"></script> -->
  </body>
</html>
