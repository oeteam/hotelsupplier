  
function successalert() {
	var notify = $.notify('<strong>Saving</strong> Do not close this page...', {
	allow_dismiss: false,
	showProgressbar: true
});

setTimeout(function() {
	notify.update({'type': 'success', 'message': '<strong>Success</strong> Your page has been saved!', 'progress': 25});
}, 4500);
}
