$(document).ready(function() {
     alert("kmkmkk");
      

  });